set -x

python run_non_ipynb_new_final_model_chunks.py "Chinese" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Chinese" 5000 10000

python run_non_ipynb_new_final_model_chunks.py "English" 0 5000
python run_non_ipynb_new_final_model_chunks.py "English" 5000 10000
python run_non_ipynb_new_final_model_chunks.py "English" 10000 15000

python run_non_ipynb_new_final_model_chunks.py "French" 0 5000
python run_non_ipynb_new_final_model_chunks.py "French" 5000 10000
python run_non_ipynb_new_final_model_chunks.py "French" 10000 15000

python run_non_ipynb_new_final_model_chunks.py "German" 0 5000
python run_non_ipynb_new_final_model_chunks.py "German" 5000 10000
python run_non_ipynb_new_final_model_chunks.py "German" 10000 15000

python run_non_ipynb_new_final_model_chunks.py "Hebrew" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Hebrew" 5000 10000

python run_non_ipynb_new_final_model_chunks.py "Italian" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Italian" 5000 10000
python run_non_ipynb_new_final_model_chunks.py "Italian" 10000 15000

python run_non_ipynb_new_final_model_chunks.py "Poland" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Poland" 5000 10000

python run_non_ipynb_new_final_model_chunks.py "Portuguese" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Portuguese" 5000 10000

python run_non_ipynb_new_final_model_chunks.py "Russian" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Russian" 5000 10000

python run_non_ipynb_new_final_model_chunks.py "Spanish" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Spanish" 5000 10000

python run_non_ipynb_new_final_model_chunks.py "Swedish" 0 5000
python run_non_ipynb_new_final_model_chunks.py "Swedish" 5000 10000
