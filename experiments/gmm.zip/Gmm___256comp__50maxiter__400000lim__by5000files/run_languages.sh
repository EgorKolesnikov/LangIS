set -x

python run_non_ipynb_new_final_model.py "Chinese"
python run_non_ipynb_new_final_model.py "English"
python run_non_ipynb_new_final_model.py "French"
python run_non_ipynb_new_final_model.py "German"
python run_non_ipynb_new_final_model.py "Hebrew"
python run_non_ipynb_new_final_model.py "Italian"
python run_non_ipynb_new_final_model.py "Poland"
python run_non_ipynb_new_final_model.py "Portuguese"
python run_non_ipynb_new_final_model.py "Russian"
python run_non_ipynb_new_final_model.py "Spanish"
python run_non_ipynb_new_final_model.py "Swedish"
